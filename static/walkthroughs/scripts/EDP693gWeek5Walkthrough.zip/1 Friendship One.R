# FRIENDSHIP GROUPS (AKA CLIQUES) - Reducing Networks

# For this session, we'll use a few different packages. 
# - "sna" is a social-network-analysis package similar to igraph, but with some different and useful functions. 
# - "cluster" is a generic cluster-analysis package with applications beyond the social-network context. 

# Load the packages (you will probably have to install the latter two)
library(igraph)
library(cluster)
library(NetData)

# Call a data file from within the NetData package
data(studentnets.M182, package = "NetData")

# All data sets in the all loaded packages
data()

# Data set in a particular package: #try(data(package = "DATASETNAME"))
try(data(package = "NetData"))

# We will be looking at the following data sets within an Honors Algebra II class:
# - "friend_df" contains self-reported friendship ties
# - "social_df" contains observed social interactions
# - "task_df" contains ties based on common task activities
# - "m182_full_data_frame" contains all of the above
m182_full_data_frame
head(m182_full_data_frame, n = 10)

head(friend_df,n = 10)
head(social_df,n = 10)
head(task_df,n = 10) 

# Remove all of the zero edges
m182_full_nonzero_edges <- subset(m182_full_data_frame, (friend_tie > 0 | social_tie > 0 | task_tie > 0))
head(m182_full_nonzero_edges, n = 10)

# Create a graph object
m182_full <- graph.data.frame(m182_full_nonzero_edges) 
summary(m182_full)

# Plot full network
full_layout <- layout.fruchterman.reingold(m182_full)
plot(m182_full, layout=full_layout, edge.arrow.size=.5)

# Create a subnetwork based on edge attributes
m182_friend <- delete.edges(m182_full, E(m182_full)[get.edge.attribute(m182_full,name = "friend_tie")==0])
summary(m182_friend)

m182_social <- delete.edges(m182_full, E(m182_full)[get.edge.attribute(m182_full,name = "social_tie")==0])
summary(m182_social)

m182_task <- delete.edges(m182_full, E(m182_full)[get.edge.attribute(m182_full,name = "task_tie")==0])
summary(m182_task)

# Look at the plots for each subnetwork
friend_layout <- layout.fruchterman.reingold(m182_friend)
plot(m182_friend, layout=friend_layout, main="friend", edge.arrow.size=.5)

social_layout <- layout.fruchterman.reingold(m182_social)
plot(m182_social, layout=social_layout, main="social", edge.arrow.size=.5)

task_layout <- layout.fruchterman.reingold(m182_task)
plot(m182_task, layout=task_layout, main="task", edge.arrow.size=.5)

# Simplifying the data set: Using an undirected set and removing isolated vertices. 
m182_friend_und <- as.undirected(m182_friend, mode='collapse')
plot(m182_friend_und)

no_iso <-V(m182_friend_und)[degree(m182_friend_und)==0]
m182_friend_no_iso <- igraph::delete.vertices(m182_friend_und, no_iso)

summary(m182_friend)
summary(m182_friend_no_iso)
plot(m182_friend_no_iso)

# Count the number of remaining vertices and edges
vcount(m182_friend_no_iso)
ecount(m182_friend_no_iso)

# Simplifying the data set: Only removing isolated vertices.
iso <- V(m182_friend)[igraph::degree(m182_friend)==0]
m182_friend_vert_full <- igraph::delete.vertices(m182_friend,iso)
summary(m182_friend_vert_full)
plot(m182_friend_vert_full)

