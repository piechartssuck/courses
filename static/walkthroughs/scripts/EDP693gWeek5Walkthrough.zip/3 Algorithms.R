# FRIENDSHIP GROUPS (AKA CLIQUES) - Community Structure Algorithms 
# Set of common community detection algorithms. For an explanation of each,
# please refer to Community Structures Algorithms.pdf
# Additionally, this site has some detailed information: 
# https://www.r-bloggers.com/summary-of-community-detection-algorithms-in-igraph-0-6/

g <- m182_friend_no_iso

# Calculate edge betweeness and heirarchy (if applicable k > 2)
ceb <- cluster_edge_betweenness(g)
dendPlot(ceb, mode="hclust")
plot(g)

g1 <- simplify(g)
fa <- fastgreedy.community(g1)

la <- label.propagation.community(g)
le <- leading.eigenvector.community(g)
ml <- multilevel.community(g)
oc <- optimal.community(g)
sp <- spinglass.community(g)
wc <- walktrap.community(g)
ic <- infomap.community(g)

# Plot the community graph
plot(ceb, g)

# Examine the community detection igraph object
class(ceb)

# Calculate the number of communities
length(ceb) 

# Find the community membership for each node
membership(ceb) 

# Display how modular the graph partitioning is
modularity(ceb) 

# Use boolean vectors (TRUE for edges across communities)
crossing(ceb, g) 

# pdf(file="criteria_SNAPATH__COMS.pdf")
# plot(ceb, g, edge.color = "gray80", main="Community structure")

# Plot all 9 community graphs in 3 rows and 3 columns:
op <- par(mfrow = c(3, 3))

# Set your margins (The 'mar' argument of 'par' sets the width of the margins in the order: 
# 'bottom', 'left', 'top', 'right'. The default is to set 'left' to 4, here I have changed it to 3)
par(mar=c(5,4,4,4)+.1)

# Plot each assignment
plot(ceb, g,vertex.label.cex=0.7, vertex.label.color="black", vertex.label.font=1, vertex.label.dist=0,
     edge.color = "gray80", main="Cluster Edge Betweenness")
plot(fa, g1,vertex.label.cex=0.7, vertex.label.color="black", vertex.label.font=1, vertex.label.dist=0,
     edge.color = "gray80", main="Fastgreedy Community")
plot(la, g,vertex.label.cex=0.7, vertex.label.color="black", vertex.label.font=1, vertex.label.dist=0,
     edge.color = "gray80", main="Label Propagation Community")
plot(le, g,vertex.label.cex=0.7, vertex.label.color="black", vertex.label.font=1, vertex.label.dist=0,
     edge.color = "gray80", main="Leading Eigenvector Community")
plot(ml, g,vertex.label.cex=0.7, vertex.label.color="black", vertex.label.font=1, vertex.label.dist=0,
     edge.color = "gray80", main="Multilevel Community")
plot(oc, g,vertex.label.cex=0.7, vertex.label.color="black", vertex.label.font=1, vertex.label.dist=0,
     edge.color = "gray80", main="Optimal Community")
plot(sp, g,vertex.label.cex=0.7, vertex.label.color="black", vertex.label.font=1, vertex.label.dist=0,
     edge.color = "gray80", main="Spinglass Community")
plot(wc, g,vertex.label.cex=0.7, vertex.label.color="black", vertex.label.font=1, vertex.label.dist=0,
     edge.color = "gray80", main="Walktrap Community")
plot(ic, g,vertex.label.cex=0.7, vertex.label.color="black", vertex.label.font=1, vertex.label.dist=0,
     edge.color = "gray80", main="Infomap Community")

# Return output to the terminal
# dev.off()

