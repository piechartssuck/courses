# This script is OPTIONAL and requires an additional install.
# Before running this code, this script requires ImageMagick from
# http://www.imagemagick.org/script/binary-releases.php
# Scroll down to the Windows/Mac section (you probably do not want
# the Unix files at the top unless you are running Linux) 
# Please note that you assume full responsibility for this install. This 
# isn't to scare you, but simply to notify you of the instructor's policy. 

#Edge Betweenness Animation#
# Load the package "animation"
library(animation)

# Run the loop - the code produces an animation of the edge-betweeness method
jitter.ani <-function(x, g){
  
  l <- layout.kamada.kawai(g, niter=1000)
  ebc <- edge.betweenness.community(g)
  
  colbar <- rainbow(6)
  colbar2 <- c(rainbow(5), rep("black",15))
  
  for (i in 1:x) {
    g2 <- igraph::delete.edges(g, ebc$removed.edges[seq(length=i-1)])
    eb <- edge.betweenness(g2)
    cl <- clusters(g2)$membership
    q <- modularity(g, cl)
    E(g2)$color <- "grey"
    E(g2)[ order(eb, decreasing=TRUE)[1:5]-1 ]$color <- colbar2[1:5]
    
    E(g2)$width <- 1
    E(g2)[ color != "grey" ]$width <- 2
    
    plot(g2, layout=l, vertex.size=12,
         edge.label.color="red", vertex.color=colbar[cl+2],
         edge.label.font=2)
    title(main=paste("Q=", round(q,3)), font=2)
    ty <- seq(1,by=-strheight("1")*1.5, length=20)
    text(-1.3, ty, adj=c(0,0.5), round(sort(eb, dec=TRUE)[1:20],2),
         col=colbar2, font=2)
  }
}

#Save the gif animation
saveGIF(jitter.ani(20, m182_friend_no_iso), interval = 0.5, outdir = getwd())

# Get an adjacency matrix based on the network with isolated pieces removed.
friend_adj_mat_no_iso <- get.adjacency(m182_friend_no_iso)
friend_adj_mat_no_iso
num_vertices = nrow(friend_adj_mat_no_iso)
num_vertices

# Community detection at work
# Load the package "sna"
library(sna)


# Run the loop - the code loops through each possible community that can be found 
# using the edge-betweenness method.
ideal_observed_cors = vector()
for (i in 0:(num_vertices-1)) {
  num_comms = (num_vertices - i)
  cat('number of communities: ', num_comms, '\n')
  community <- cutat(m182_friend_no_iso, friend_comm_eb$merges, i)
  print(community)
  idealized_comm_mat <- matrix(nrow=num_vertices, ncol=num_vertices)
  
  for (m in 1:num_vertices) {
    for (n in 1:num_vertices) {
      if (m==n) {
        idealized_comm_mat[m,n] = 0
      } else if (community$membership[m] == community$membership[n]) {
        idealized_comm_mat[m,n] = 1
      } else {
        idealized_comm_mat[m,n] = 0
      }
    }
  }
  print(idealized_comm_mat) 
  
  if (num_comms > 1 & num_comms < num_vertices) {
    ideal_observed_cors <- append(ideal_observed_cors, (gcor(idealized_comm_mat, friend_adj_mat_no_iso)))
    print(ideal_observed_cors[length(ideal_observed_cors)])
  } else {
    ideal_observed_cors <- append(ideal_observed_cors, 0)
    print('unable to calcuate correlation; setting value to 0')
  }
  cat('\n')
}
ideal_observed_cors <- rev(ideal_observed_cors)
ideal_observed_cors 
m182_friend_no_iso
