# FRIENDSHIP GROUPS (AKA CLIQUES) - Community Detection 
# a subset of nodes within the graph such that connections between the nodes 
# are denser than connections with the rest of the network

# Some definitions:
# - modularity: Measures of the strength of divisions of a network into modules (e.g.
#               groups, clusters or communities). Networks with high modularity illicit 
#               dense connections between nodes within modules but sparse connections 
#               between nodes in different modules.
# - membership - The module that an actor is included in (may be singular).


# Walktrap: Detects communities through a series of short random walks, with 
# the idea that the vertices encountered on any given random walk are more likely 
# to be within a community than not.

# (Optional) - If you want to go deeper into random walks, check out this video on 
# YouTube: https://www.youtube.com/watch?v=stgYW6M5o4k

friend_comm_wt <- walktrap.community(m182_friend_vert_full)
friend_comm_wt
modularity(friend_comm_wt)
membership(friend_comm_wt)

# Create community detection plots
old.par<-par(mfrow=c(1,2))

layout <-layout.fruchterman.reingold(m182_friend_vert_full)
friend_comm_dend_wt <- as.dendrogram(friend_comm_wt, use.modularity=TRUE)

plot(friend_comm_wt, m182_friend_vert_full, layout=layout, vertex.size=15, edge.arrow.size=.2)
plot(friend_comm_dend_wt)

par(old.par)


# Edge betweenness: The idea of the edge betweenness based community structure detection 
# is that it is likely that edges connecting separate modules have high edge betweenness  
# as all the shortest paths from one module to another must traverse through them. 

friend_comm_eb <- edge.betweenness.community(m182_friend_vert_full)
friend_comm_eb
modularity(friend_comm_eb)
membership(friend_comm_eb)

# Create community detection plots
old.par<-par(mfrow=c(1,2))

layout <-layout.fruchterman.reingold(m182_friend_vert_full)
plot(friend_comm_eb, m182_friend_vert_full, layout=layout, vertex.size=15, edge.arrow.size=.2)

friend_comm_dend_eb <- as.dendrogram(friend_comm_eb, use.modularity=TRUE)
plot(friend_comm_dend_eb)

par(old.par)


plot(friend_comm_eb, m182_friend_no_iso, layout=layout, vertex.size=15, edge.arrow.size=.2)
friend_comm_eb$removed.edges

# Calculate the edge betweenness score (the measure ofthe number of shortest paths 
# through an edge by calculating the edge betweenness of the graph, removing the edge 
# with the highest edge betweenness score, then recalculating edge betweenness of the 
# edges and again removing the one with the highest score.)

friend_comm_eb1 <- cluster_edge_betweenness(m182_friend_no_iso)
friend_comm_eb1
plot(friend_comm_eb1, m182_friend_no_iso)

# Run the loop to calculate all modularities
mods <- sapply(0:ecount(m182_friend_no_iso), 
function(i){
  g2 <- igraph::delete.edges(m182_friend_no_iso, friend_comm_eb1$removed.edges[seq(length=i)])
  cl <- clusters(g2)$membership
  
# compute modularity on the original graph g 
  modularity(m182_friend_no_iso,cl)
})

# Plot the modularities to observe clustering effects and similarities
plot(mods, pch=20)

# View the communities by node coloring via clustering
V(m182_friend_no_iso)$color=clusters(cut_plot)$membership
m182_friend_no_iso$layout <- layout.fruchterman.reingold
plot(m182_friend_no_iso)

# Plot the graph if the sparse edges were removed (called a disconnected network)
cut_plot<-igraph::delete.edges(m182_friend_no_iso, friend_comm_eb1$removed.edges[seq(length=which.max(mods)-1)])
plot(cut_plot)
