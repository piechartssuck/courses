# Twitter Analysis - DESCRIPTIVES: WORD FREQUENCY AND CLOUD

# Number Of Times A Term Appears
termFreqency <- rowSums(tdm)
termFreqency

# Subset frequent words
termFreqency <- subset(termFreqency, termFreqency>70)
termFreqency

# Bar Plot
barplot(termFreqency, las=2, col=rainbow(30))

# If the plot labels need to be shifted
me <- barplot(termFreqency, axes = TRUE, axisnames = FALSE, las=2, col=rainbow(30))
text(me[,1], -1.0, srt = 60, adj = c(1.1,1.1), xpd = TRUE, labels = names(termFreqency) , cex=0.6)

# (Optional) Remove word "amp" and recompile
cleanset <- tm_map(cleanset, removeWords, c('amp'))
cleanset <- tm_map(cleanset, stripWhitespace)
tdm <- TermDocumentMatrix(cleanset, control = list(WordLength=c(1,Inf)))
tdm <- as.matrix(tdm)
termFreqency <- rowSums(tdm)
termFreqency <- subset(termFreqency, termFreqency>70)
barplot(termFreqency, las=2, col=rainbow(30))
me <- barplot(termFreqency, axes = TRUE, axisnames = FALSE, las=2, col=rainbow(30))
text(me[,1], -1.0, srt = 60, adj = c(1.1,1.1), xpd = TRUE, labels = names(termFreqency) , cex=0.6)

# Plot the set using ggplot2
library(ggplot2)
df <- data.frame(term = names(termFreqency), freq = termFreqency)
ggplot(df, aes(x = term, y = freq)) + geom_bar(stat = "identity") +
  xlab("Terms") + ylab("Count") + coord_flip()


# Wordcloud 
# - max.words will plot the specified number of words and discard least frequent terms
# - min.freq will discard all terms whose frequency is below the specified value
library(wordcloud)
wordFreq <- sort(rowSums(tdm), decreasing = TRUE)
set.seed(123)
wordcloud(words = names(wordFreq), freq = wordFreq, random.order = F,  max.words = 30)

# Expand/Reduce Word Cloud Clutter For Maximum = 50 words
wordcloud(words = names(wordFreq), freq = wordFreq, random.order = F, max.words = 50)

# Expand/Reduce Word Cloud Clutter For Minimum Frequency = 50 times
wordcloud(words = names(wordFreq), freq = wordFreq, random.order = F, min.freq = 50)

# Add Colors
wordcloud(words = names(wordFreq), freq = wordFreq, random.order = F, min.freq = 50, colors = rainbow(12))

# Add Different Colors
wordcloud(words = names(wordFreq), freq = wordFreq, random.order = F, min.freq = 50, 
          colors = brewer.pal(6, 'Dark2'))

# Varying The Scale
wordcloud(words = names(wordFreq), freq = wordFreq, random.order = F, min.freq = 50, 
          colors = brewer.pal(6, 'Dark2'), scale = c(7,0.2))

# Rotate Some Words
wordcloud(words = names(wordFreq), freq = wordFreq, random.order = F, min.freq = 50, 
          colors = brewer.pal(6, 'Dark2'), scale = c(3.2,0.2), rot.per = 0.8)

# More options with (wordcloud2)
library(wordcloud2)
wordFreq <- data.frame(names(wordFreq),wordFreq)
colnames(wordFreq) <- c("word","freqency")
wordcloud2(wordFreq, size = 0.5, shape = "star", rotateRatio = 0.5)

letterCloud(wordFreq, word = "Trump's tweets", size = 2)


