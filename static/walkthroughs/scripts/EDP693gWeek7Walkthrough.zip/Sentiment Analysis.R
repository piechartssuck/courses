# Twitter Analysis - SENTIMENT ANALYSIS AND STRUCTURAL NETWORKS

# Load packages
library(syuzhet)
library(lubridate)
library(ggplot2)
library(scales)
library(reshape2)
library(dplyr)

# Load a Twitter file
mydata <- read.csv("twitter.csv", 
                   header = T,stringsAsFactors=FALSE)
tweets = lapply(mydata$text, function(x) iconv(x, "latin1", "ASCII", sub=""))
tweets <- as.character(tweets)


# Get sentiment scores
sent <- get_nrc_sentiment(tweets)
head(sent)
tweets[4]

# Check the score for a word
get_nrc_sentiment('destroyed')

# Construct a bar plot
barplot(colSums(sent), las = 2, col = rainbow(10), ylab = "Count", 
        main = "Sentiment Acores for Tweets by Donald Trump")

tw <- barplot(colSums(sent), axes = TRUE, axisnames = FALSE, las=2, col = rainbow(10), 
              ylab = "Count", main = "Sentiment Acores for Tweets by Donald Trump")
text(tw[,1], -1.0, srt = 60, adj = c(1.1,1.1), xpd = TRUE, labels = names(sent), cex=0.6)


#---------------------------------------------------------------------------------------------

# (OPTIONAL) Find how terms are connected (networked) 
## source("http://www.bioconductor.org/biocLite.R") 
# from https://www2.warwick.ac.uk/fac/sci/moac/people/students/peter_cock/r/rgraphviz/

## biocLite("graph")
## biocLite("Rgraphviz")

library(graph)
library(Rgraphviz)

# Discover where terms interact
idx <- which(dimnames(tdm)$Terms %in% c("democrat", "republican"))
idx
as.matrix(tdm[idx,1:100])

# Find frequent terms
tdm <- TermDocumentMatrix(cleanset, control = list(WordLength=c(1,Inf)))
(freq.terms <- findFreqTerms(tdm, lowfreq = 70))

# Find word associations
findAssocs(tdm, "democrat", 0.2)
findAssocs(tdm, "republican", 0.2)
findAssocs(tdm, "fake", 0.2)
findAssocs(tdm, "news", 0.2)

# Find network of terms
plot(tdm, term = freq.terms, corThreshold = 0.03, weighting = T)

# To clear a plot, use 
dev.off()
