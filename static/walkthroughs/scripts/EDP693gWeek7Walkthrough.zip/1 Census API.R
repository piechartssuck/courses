## Set working directory ----
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# load libraries ----
library(tidyverse)
library(tidycensus)

# Get county migration data 
county_data <- 
  get_flows(geography = "county",
            year = 2019,
            variables = c("MOVEDIN", "MOVEDOUT"),
            output = "wide")

state_regions <-
  tibble(state.name, state.region) 

state_mig <-
  county_data %>%
  filter(str_detect(FULL2_NAME, state_regions$state.name)) %>%
  separate(FULL1_NAME, c("county_from", "state_from"), ",") %>%
  mutate(state_from = str_squish(state_from)) %>%
  separate(FULL2_NAME, c("county_to", "state_to"), ",") %>%
  mutate(state_to = str_squish(state_to)) %>%
  mutate_at(vars(starts_with("county")), str_remove, " County")
