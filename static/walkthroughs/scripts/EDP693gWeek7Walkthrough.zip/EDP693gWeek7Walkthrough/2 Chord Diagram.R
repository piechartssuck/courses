## Set working directory ----
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# Load libraries
library(tidyverse)
library(igraph)
library(tidygraph)
library(chorddiag)

movement_state <- 
  as.matrix(
    as_adjacency_matrix(
      as_tbl_graph(migration
                   ),
      attr = c("migcount"))
    )

region_pal <-
migration %>%
  select(from, to, color) %>%
  distinct() %>%
  select(color) %>%
  pull()

n <- 
  migration%>%
  filter(complete.cases(.) & !duplicated(.)) %>%  # Filter out rows with NA
  group_by(to) %>% #Filter out duplicated rows; these represent individuals in the same group
  summarize(count = n()) %>% # Group by to
  nrow() # Count the number of unique groups in from

viridis_no <- viridis_pal()(n)           # n discrete Viridis colors
group_cols <- substr(viridis_no, 0, 7)  # get rid of transparency characters ('FF')

state_cd <-
  chorddiag(data = movement_state,
            groupnamePadding = 30,
            groupPadding = 3,
            groupColors = group_cols,
            groupnameFontsize = 13 ,
            showTicks = FALSE,
            margin=150,
            tooltipGroupConnector = "   &#x25B6;   ",
            chordedgeColor = "#B3B6B7"
            ); state_cd



