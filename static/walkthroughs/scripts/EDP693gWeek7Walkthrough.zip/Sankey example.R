# Load libraries ---
library(networkD3)
library(tidyverse)
library(showtext)
font_add_google("Roboto Condensed", "roboto")
showtext_auto()

# Build the edgelist ----
# (a connection tibble is a list of flows with intensity for each flow)
edgelist <- 
  tibble(
  from = c("Student Level 1 A","Student Level 1 A", "Student Level 1 B", "Classroom Level 2 High A", "Classroom Level 2 High A", "Classroom Level 2 Mixed B"), 
  to = c("Classroom Level 2 High A","Classroom Level 2 Low A", "Classroom Level 2 Mixed B", "School Level 3 Upper A", "School Level 3 Lower A", "School Level 3 Mixed B"), 
  counts = c(14, 10, 8, 7, 5, 4)
); edgelist

# Create a node tibble with every node involved in the flow ----
nodes <- 
  tibble(name = unique(c(edgelist$from, 
                         edgelist$to))); nodes

# Set links data to the base value 0 called an index ----
# (because computers)
edges <- 
  edgelist %>%
  left_join(nodes, by = c("from" = "name")) %>%
  mutate(from = match(from, nodes$name) - 1) %>%
  mutate(to = match(to, nodes$name) - 1); edges

# Construct the network ----
sank <- 
  sankeyNetwork(Links = edges, 
                Nodes = nodes,
                Source = "from",
                Target = "to",
                Value = "counts", 
                NodeID = "name", 
                sinksRight = FALSE,
                fontFamily = "Roboto Condensed", 
                fontSize = 18, 
                width = 1500,
                height = 800,  
                nodeWidth = 20,
                nodePadding = 15,
                iterations = 0); sank

# Save the Sankey as an HTML file
# library(htmlwidgets)
# saveNetwork(sank, file = 'sank.html')

