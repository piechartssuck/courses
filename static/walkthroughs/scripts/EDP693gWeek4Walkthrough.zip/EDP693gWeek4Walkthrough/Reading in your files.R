# Network Visualization Options

# READING IN YOUR FILES

# Bring in your csv file if you know the path: 
nodes <- read.csv("mydata.csv", header = TRUE, sep=",")
mappings <- read.csv("mydata.csv", header = TRUE, sep=",")

# Bring in your csv file if you want to locate the path:
nodes <- read.csv(file.choose(),header=TRUE,sep=",") 
mappings <- read.csv(file.choose(),header=TRUE,sep=",") 

# Examine the nodes
head(nodes)
tail(nodes)
nrow(nodes); length(unique(nodes$id.number))

# Examine the mappings
head(mappings)
tail(mappings)
nrow(mappings); nrow(unique(mappings[,c("from", "to")]))

#Remove duplicate mappings to create unique from-to links
mappings <- aggregate(mappings[,3], mappings[,-3], sum)
mappings <- mappings[order(mappings$from, mappings$to),]
colnames(mappings)[4] <- "weight"
rownames(mappings) <- NULL

# Check if duplicates were removed
nrow(mappings); nrow(unique(mappings[,c("from", "to")]))