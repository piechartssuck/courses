# Network Visualization Options

# CREATING BETTER VISUALIZATIONS

# Loading in igraph 
library(igraph)

# Combining edges and nodes using graph.data.frame
network <- graph_from_data_frame(d=mappings, vertices=nodes, directed=TRUE)

# Confirming (igraph) object
class(network)

# View all of the nodes
V(network)

# View all of the edgewise mappings
E(network)

# Plot the network
plot(network, edge.arrow.size=.4,vertex.label=NA)

# Remove loops and plot
network <- simplify(network, remove.multiple = FALSE, remove.loops = TRUE)
plot(network, edge.arrow.size=.4,vertex.label=NA)

# Plot with curved edges
plot(network, edge.arrow.size=.4, edge.curved=.4, vertex.label=NA)

# Set edge color to light grey, and the node color to light blue
# Replace the vertex label with the node names stored in "media"
plot(network, edge.arrow.size=.2, edge.curved=0, edge.color = "gray80",
     vertex.color="light blue", vertex.frame.color="#555555",
     vertex.label=V(network)$media.type, vertex.label.color="black",
     vertex.label.cex=.7)

# Generate colors based on media type:
colrs <- c("green", "lavender", "light blue", "yellow")
V(network)$color <- colrs[V(network)$media.type]
plot(network, edge.arrow.size=.4, vertex.label=NA)

# Set node size based on audience size:
V(network)$size <- V(network)$audience.size*0.00000020
plot(network, edge.arrow.size=.4, vertex.label=NA)

# Set edge width based on weight:
E(network)$width <- E(network)$weight/12
plot(network, edge.arrow.size=.4, vertex.label=NA)

# Change arrow size and edge color and plot the network again
plot(network, edge.arrow.size=.2, edge.color = "gray80", vertex.label=NA)

# Add a legend
plot(network, edge.arrow.size=.2, edge.color = "gray80", vertex.label=NA)
legend(x=-1.5, y=-1.1, c("Newspaper","Cable News", "Network News", "Online News"), 
       pch=21, col="#777777", pt.bg=colrs, pt.cex=2, cex=.7, bty="n", ncol=1)
