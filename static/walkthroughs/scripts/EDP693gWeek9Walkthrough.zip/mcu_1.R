# Set source as location ----
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# Load libraries ----
library(tidyverse)
library(rvest)
library(deeplr)

deepkey <- "0814fd7e-14db-9106-6a55-2c9f40ceea16:fx"

link <- "https://fr.wikipedia.org/w/index.php?title=Liste_des_films_de_l%27univers_cin%C3%A9matographique_Marvel&oldid=144793972#Personnages"

mcu <- 
  read_html(link) %>%
  html_table(fill = TRUE) %>%
  .[[5]] %>%
  mutate(across(everything(), ~ifelse(. == "", NA, as.character(.)))) %>%
  mutate(Film = str_replace_all(Film, "L'incroyable Hulk", "The Incredible Hulk")) %>%
  mutate(Film = str_replace_all(Film, "le Monde des ténèbres", "The Dark World")) %>%
  mutate(Film = str_replace_all(Film, "Le Soldat de l'hiver", "The Winter Soldier")) %>%
  mutate(Film = str_replace_all(Film, "Les Gardiens de la Galaxie", "The Guardians of the Galaxy")) %>%
  mutate(Film = str_replace_all(Film, "L'Ère d'Ultron", "The Age of Ultron")) %>%
  mutate(Film = str_replace_all(Film, "et la Guêpe", "and the Wasp")) %>%
  rename("Black Widow" = "Veuve noire",
         "Hawkeye" = "Œil de Faucon",
         "Scarlet Witch" = "Sorcière rouge") %>%
  mutate(across(!Film, ~ifelse(is.na(.), 0, 1)))
  
deeplr::available_languages2(deepkey) %>%
  as_tibble() %>%
  view()

mcu_french <- 
  read_html(link) %>%
  html_table(fill = TRUE) %>%
  .[[5]] %>%
  mutate(across(everything(), ~ifelse(. == "", NA, as.character(.))))

mcu_translated <- 
  mcu_french %>%
  mutate(Film =
           translate2(
             text = mcu_french$Film,
             target_lang = "EN",
             auth_key = deepkey
             )
           ) %>%
  rename_all(~translate2(
    text = names(mcu_french),
    target_lang = "EN",
    auth_key = deepkey
    )
  ) %>%
  rename(Hawkeye = "Falcon's Eye",
         "Scarlet Witch" = "Red Witch") %>%
  mutate(across(!Film, ~ifelse(is.na(.), 0, 1)))
