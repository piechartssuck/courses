# Set source as location ----
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# Load libraries ----
library(tidyverse)
library(lubridate)
library(magrittr)
library(tidygraph) # install using devtools::install_github('thomasp85/tidygraph')
library(ggraph)
library(igraph)
library(graphlayouts) 
library(patchwork)
library(rvest)
library(visNetwork)
library(wesanderson)
library(showtext)
font_add_google("Roboto Condensed", "roboto")
showtext_auto()

# Get MCU Phase data ----
phase_one <- "https://en.wikipedia.org/wiki/Marvel_Cinematic_Universe:_Phase_One"
phase_two <- "https://en.wikipedia.org/wiki/Marvel_Cinematic_Universe:_Phase_Two"
phase_three <- "https://en.wikipedia.org/wiki/Marvel_Cinematic_Universe:_Phase_Three"

## Phase One ----
phase_one_movies <- 
  read_html(phase_one) %>%
  html_table(fill = TRUE) %>%
  .[[3]] %>%
  mutate(across(everything(), ~ifelse(. == "", NA, as.character(.)))) %>%
  select(Film = c(1),
         Date = c(2),
         Directors = c(3)) %>%
  mutate(Date = mdy(Date)) %>%
  mutate(Date = year(Date)) %>%
  mutate(Directors = str_remove_all(Directors, "\\[.+?\\]")) %>%
  add_column(Category = "Phase One")

## Phase Two ----
phase_two_movies <- 
  read_html(phase_two) %>%
  html_table(fill = TRUE) %>%
  .[[3]] %>%
  mutate(across(everything(), 
                ~ifelse(. == "", NA, as.character(.)))) %>%
  select(Film = c(1),
         Date = c(2),
         Directors = c(3)) %>%
  mutate(Date = mdy(Date)) %>%
  mutate(Date = year(Date)) %>%
  mutate(Directors = str_remove_all(Directors, "\\[.+?\\]")) %>%
  add_column(Category = "Phase Two")
 
## Phase Three ---- 
phase_three_movies <- 
  read_html(phase_three) %>%
  html_table(fill = TRUE) %>%
  .[[3]] %>%
  mutate(across(everything(), 
                ~ifelse(. == "", NA, as.character(.)))) %>%
  select(Film = c(1),
         Date = c(2),
         Directors = c(3)) %>%
  mutate(Date = mdy(Date)) %>%
  mutate(Date = year(Date)) %>%
  mutate(Directors = str_remove_all(Directors, "\\[.+?\\]")) %>%
  add_column(Category = "Phase Three")

## Combine Phase data ----
mcu_movies <-
  bind_rows(phase_one_movies,
            phase_two_movies,
            phase_three_movies) %>%
  mutate(Film = str_replace(Film,
                            "Marvel's The Avengers",
                            "Avengers"))

### Save common dplyr commands for reuse ----
repipe <- 
  . %>%
  mutate(across(everything(), 
                ~ifelse(. == "", NA, as.character(.)))) %>%
  select(Film = c(1),
         Date = c(2),
         Directors = c(3)) %>%
  mutate(Date = mdy(Date)) %>%
  mutate(Date = year(Date)) %>%
  mutate(Directors = str_remove_all(Directors, "\\[.+?\\]"))

## Phase One ---- 
phase_one_movies <- 
  read_html(phase_one) %>%
  html_table(fill = TRUE) %>%
  .[[3]] %>%
  repipe() %>%
  add_column(Category = "Phase One")

## Phase Two ---- 
phase_two_movies <- 
  read_html(phase_two) %>%
  html_table(fill = TRUE) %>%
  .[[3]] %>%
  repipe() %>%
  add_column(Category = "Phase Two")

## Phase Three ---- 
phase_three_movies <- 
  read_html(phase_three) %>%
  html_table(fill = TRUE) %>%
  .[[3]] %>%
  repipe() %>%
  add_column(Category = "Phase Three")

## Combine Phase data ----
movies <-
  bind_rows(phase_one_movies,
            phase_two_movies,
            phase_three_movies) %>%
  mutate(Film = str_replace(Film,
                            "Marvel's The Avengers",
                            "Avengers"))


# Build a Network Graph ----
## Create an edge set ----
mcu_edges <- 
  mcu_translated %>%
  pivot_longer(cols = -Film) %>%
  filter(value == 1) %>%
  select(-value) %>%
  mutate(Film = str_replace(Film,
                            "Captain America : First Avenger",
                            "Captain America: The First Avenger")) %>%
  select(from = name,
         to = Film)

### Compare data frame columns ----
setdiff(movies %>% select(Film), 
        mcu_edges %>% select(Film))

## Create nodes set ----
### From ----
mcu_from_nodes <-
  mcu_edges %>%
  select(from) %>%
  rename(node = from)

### To ----
mcu_to_nodes <-
  mcu_edges %>%
  select(to) %>%
  rename(node = to)

### Combined From and To ----
mcu_nodes <- 
  bind_rows(mcu_from_nodes,
            mcu_to_nodes) %>%
  distinct() %>%
  left_join(mcu_movies,
            by = c("node" = "Film")) %>%
  arrange(Date) %>%
  mutate(Category = replace_na(Category, "Character")) %>%
  mutate(Category = factor(Category, levels = c("Phase One", "Phase Two", "Phase Three", "Character"))); mcu_nodes

## Build ggraph data ----
mcu_graph_data <- 
  tbl_graph(nodes = mcu_nodes,
            edges = mcu_edges) %>%
  mutate(degree = centrality_degree(), # measures connections or ties a single node has
         closeness = centrality_closeness(), # measures how often a node lies on the shortest path between other nodes
         betweenness = centrality_betweenness(), # measures how close a node is to all other nodes
         eigenvalue = centrality_eigen(), # measures a node’s influence based on the number of links it has to other nodes
         pagerank = centrality_pagerank(), # eigenvalue centrality + assigning nodes a score based on their connections, and their connections’ connections  
         ) 

### Nodes set ----
nodes <- 
  mcu_graph_data %>% 
  activate(nodes) %>% 
  as_tibble(); nodes 

### Edge set ----
edges <- 
  mcu_graph_data %>% 
  activate(edges) %>% 
  as_tibble(); edges 

## Set a seed for reproducibility ----
set.seed(123)

## Plot Network ----
### Degree centrality, Nicely layout, geom_edge_fan ----
ggraph(mcu_graph_data, 
       layout = "nicely") +
  geom_edge_fan(alpha = 0.2) +
  geom_node_point(aes(size = degree, 
                      color = Category), 
                  alpha = 0.9) + 
  scale_color_manual(values = c(wes_palette("GrandBudapest1")[1:3],
                                "#79cdcd")) +
  geom_node_label(aes(label = node), 
                 size = 3.5, 
                 repel = TRUE,
                 family = "roboto") +
  scale_size(range = c(3,10)) +
  theme_graph(base_family = "roboto") +
  theme(plot.background = element_rect(fill = "#f8f2e4"),
        legend.title = element_text(size = 16,
                                    face = "bold",
                                    color = "#666666"),
        legend.title.align = 0.5,
        legend.text = element_text(size = 12,
                                   color = "#666666"),
        legend.position="bottom")  +
  labs(title = "Degree Centrality in the Marvel Cinematic Universe") + 
  guides(size = "none",
         color = guide_legend(override.aes = list(size = 4))) +
  coord_equal()
  
### Betweenness centrality, Kamada-Kawai layout, geom_edge_arc
ggraph(mcu_graph_data, 
       layout = "kk") +
  geom_edge_arc(alpha = 0.2,
                strength = 0.3) +
  geom_node_point(aes(size = betweenness, 
                      color = Category), 
                  alpha = 0.9) + 
  scale_color_manual(values = c(wes_palette("GrandBudapest1")[1:3],
                                "#79cdcd")) +
  geom_node_label(aes(label = node), 
                  size = 3.5, 
                  repel = TRUE,
                  family = "roboto") +
  scale_size(range = c(3,10)) +
  theme_graph(base_family = "roboto") +
  theme(plot.background = element_rect(fill = "#f8f2e4"),
        legend.title = element_text(size = 16,
                                    face = "bold",
                                    color = "#666666"),
        legend.title.align = 0.5,
        legend.text = element_text(size = 12,
                                   color = "#666666"),
        legend.position="bottom") +
  labs(title = "Betweenness Centrality in the Marvel Cinematic Universe") + 
  guides(size = "none",
         color = guide_legend(override.aes = list(size = 4),
                              title.position = "bottom")) +
  coord_equal()

#### Save ggplot chunk
replot <- 
  list(
    scale_color_manual(values = c(wes_palette("GrandBudapest1")[1:3],
                                  "#79cdcd")),
      geom_node_label(aes(label = node), 
                      size = 3.5, 
                      repel = TRUE,
                      family = "roboto"),
      scale_size(range = c(3,10)),
      theme_graph(base_family = "roboto"),
      theme(plot.background = element_rect(fill = "#f8f2e4"),
            legend.title = element_text(size = 16,
                                        face = "bold",
                                        color = "#666666"),
            legend.title.align = 0.5,
            legend.text = element_text(size = 12,
                                       color = "#666666"),
            legend.position="bottom"),
    guides(size = "none",
           color = guide_legend(override.aes = list(size = 4))),
      coord_equal()
  )

### Closeness centrality, graph optimized layout, geom_edge_arc
ggraph(mcu_graph_data, 
       layout = "graphopt") + 
  geom_edge_link(aes(start_cap = label_rect(node1.node), 
                     end_cap = label_rect(node2.node)), 
                 arrow = arrow(type = "closed", 
                               length = unit(3, 'mm')),
                 color = "#cccccc")  +
  geom_node_point(aes(size = closeness, 
                      color = Category), 
                  alpha = 0.9) +
  replot +
  labs(title = "Closeness Centrality in the Marvel Cinematic Universe") 

### Eigenvalue centrality, graph optimized layout, geom_edge_arc ----
ggraph(mcu_graph_data, 
       layout = "graphopt") + 
  geom_edge_link(aes(alpha = stat(index),
                     color = from),
                 width = 1,
                 show.legend = FALSE)  +
  geom_node_point(aes(size = eigenvalue, 
                      color = Category), 
                  alpha = 0.9) +
  replot +
  labs(title = "Eigenvalue Centrality in the Marvel Cinematic Universe")

### PageRank centrality, stress layout, geom_edge_link ----
ggraph(mcu_graph_data, 
       layout = "stress") +
  geom_edge_link(alpha = 0.2) +
  geom_node_point(aes(size = pagerank, 
                      color = Category), 
                  alpha = 0.9) + 
  replot +
  labs(title = "PageRank Centrality in the Marvel Cinematic Universe") 

## Additional layouts ----
#### Get node ids ----
node.ids <- 
  mcu_graph_data %>% 
  activate(nodes) %>% 
  mutate(id = row_number()) %>% 
  as_tibble() %>%
  relocate(id, .before = node) %>%
  arrange(desc(eigenvalue))

### Eigenvalue centrality, focus layout, geom_edge_fan ----
ggraph(mcu_graph_data, 
       layout = "focus",
       focus = 19) +
  geom_edge_fan(alpha = 0.2) +
  geom_node_point(aes(size = eigenvalue, 
                      color = Category), 
                  alpha = 0.9) + 
  replot +
  labs(title = "Eigenvalue Centrality in the Marvel Cinematic Universe") 

### PageRank centrality, focus layout with circle, geom_eg ----
ggraph(mcu_graph_data, 
       layout = "focus",
       focus = 19) +
  draw_circle(col = "#a7c5bd", 
              use = "focus",
              max.circle = 3) +
  geom_edge_fan(alpha = 0.2) +
  geom_node_point(aes(size = pagerank, 
                      color = Category), 
                  alpha = 0.9) + 
  replot +
  labs(title = "Pagerank Centrality in the Marvel Cinematic Universe")

### Closeness centrality, centrality layout, geom_eg ----
closecent <-
  ggraph(mcu_graph_data, 
       layout = "centrality",
       cent = closeness) +
  geom_edge_fan(alpha = 0.2) +
  geom_node_point(aes(size = closeness, 
                      color = Category), 
                  alpha = 0.9) + 
  replot +
  theme(plot.title = element_text(hjust = 0.5,
                                  color = "#eb7b59")) +
  labs(title = "Closeness"); closecent

### Eigenvalue centrality, centrality layout, geom_eg
eigencent <- 
  ggraph(mcu_graph_data, 
         layout = "centrality",
         cent = eigenvalue) +
  geom_edge_fan(alpha = 0.2) +
  geom_node_point(aes(size = eigenvalue, 
                      color = Category), 
                  alpha = 0.9) + 
  replot +
  theme(plot.title = element_text(hjust = 0.5,
                                  color = "#00816a")) +
  labs(title = "Eigenvalue"); eigencent

### Betweenness centrality, centrality layout, geom_eg
betcent <-
  ggraph(mcu_graph_data, 
         layout = "centrality",
         cent = eigenvalue) +
  geom_edge_fan(alpha = 0.2) +
  geom_node_point(aes(size = betweenness, 
                      color = Category), 
                  alpha = 0.9) + 
  replot +
  theme(plot.title = element_text(hjust = 0.5,
                                  color = "#005881")) +
  labs(title = "Betweenness"); betcent

## Patch them together ----
closecent + eigencent + betcent + 
  plot_annotation(title = "Centrality Measures in the Marvel Cinematic Universe",
                  theme = theme(plot.title = element_text(size = 20,
                                                          family = "roboto",
                                                          face = "bold",
                                                          hjust = 0.5,
                                                          margin = margin(t = 15,
                                                                          b = 15)),
                                plot.background = element_rect(fill="#f8f2e4"))) +
  plot_layout(guides = "collect") & 
  theme(legend.position = "bottom",
        legend.margin = margin(t = 2,
                               b = -0.5,
                               unit = "cm"))

# Faceting ----
ggraph(mcu_graph_data, 
       layout = "centrality",
       cent = eigenvalue) +
  geom_edge_fan(alpha = 0.2) +
  geom_node_point(aes(size = eigenvalue, 
                      color = Category), 
                  alpha = 0.9) + 
  replot +
  theme(plot.title = element_text(hjust = 0.5)) +
  labs(title = "Directors of Marvel Cinematic Universe") +
  facet_nodes(~Directors) +
  coord_cartesian() +
  theme(strip.text = element_text(size = 14))


# Visnetwork ----
## Convert tidygraph to VisNetwork ----
dataVis <- 
  mcu_graph_data %>%
  mutate(group = Category) %>%
  mutate(label = node) %>%
  toVisNetworkData(idToLabel = FALSE) 

## Plot VisNetwork ----
mcuVis <-
  visNetwork(dataVis$nodes,
           dataVis$edges,
           background = "#f8f2e4") %>%
  visLayout(randomSeed = 123) %>%
  visNodes(font = list(size = 15,
                       face = "roboto"),
           size = 15) %>%
  visEdges(arrows = "to") %>% 
  visOptions(highlightNearest = list(enabled = TRUE, 
                                     hover = TRUE), 
             selectedBy = list(variable = "Category", 
                               multiple = TRUE,
                               sort = FALSE),
             collapse = TRUE,
             nodesIdSelection = TRUE) %>% 
  visInteraction(navigationButtons = TRUE) %>%
  visPhysics(solver = "repulsion",
             repulsion = list(centralGravity = 0.5,
                              springLength = 25,
                              springConstant = 0.1,
                              avoidOverlap = 1))

mcuVis %>%
  visSave(file = "mcu.html")

htmlwidgets::saveWidget(mcuVis, "mcu.html")
