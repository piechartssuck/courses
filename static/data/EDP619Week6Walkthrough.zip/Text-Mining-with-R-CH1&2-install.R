install.packages(
  c(
    "tidyverse", "tidytext", "janeaustenr", "tidyr", "scales", "wordcloud", "reshape2", "devtools"
  )
)

devtools::install_github("ropensci/gutenbergr")
