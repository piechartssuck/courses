install.packages(
  c(
    "tidyverse", "tidytext",  "janeaustenr", "gutenbergr", "tidyr", "scales", "wordcloud", "reshape2"
  )
)
