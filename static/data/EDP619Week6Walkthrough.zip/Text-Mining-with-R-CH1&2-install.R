install.packages(
  c(
    "tidyverse", "tidytext", "janeaustenr", "tidyr", "scales", "wordcloud", "reshape2", "devtools", "pacman"
  ),
  dependencies = TRUE
)

devtools::install_github("ropensci/gutenbergr")
