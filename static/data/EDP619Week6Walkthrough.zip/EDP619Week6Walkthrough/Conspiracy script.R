## install.packages("psych", dependencies = TRUE)

## library("tidyverse")
## library("psych")
## library("reactable")
## library("polycor")

## setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

## conspiracy_data <- read_csv("ConspiracyData.csv")

## conspiracy_codebook <- read_csv("ConspiracyCodebook.csv")

## conspiracy_measures<- read_csv("ConspiracyMeasures.csv")


conspiracy_codebook %>%
  head()

conspiracy_measures


reactable(conspiracy_measures)

reactable(conspiracy_codebook)

reactable(conspiracy_codebook,
          searchable = TRUE, 
          defaultPageSize = 3)


dim(conspiracy_data)


reactable(conspiracy_data,
          searchable = TRUE, 
          defaultPageSize = 5,
          showPageSizeOptions = TRUE,
          highlight = TRUE)


conspiracy_data_10 <- conspiracy_data %>%
                      head(n=10)


scree(conspiracy_data_10)


EFA <- 
  fa(conspiracy_data_10,
     nfactors = 3)

EFA

EFA$loadings


fa.diagram(EFA)

class(EFA)

MR1_factor <- 
  conspiracy_codebook %>%
  filter(str_detect(Item, paste(c("Q12", "Q7", "Q11", "Q14", "Q1", "Q9", "Q2", "Q5"), collapse = '|')))

MR2_factor <- 
  conspiracy_codebook %>%
  filter(str_detect(Item, paste(c("Q3", "Q13", "Q8", "Q4"), collapse = '|')))

MR3_factor <- 
  conspiracy_codebook %>%
  filter(str_detect(Item, paste(c("Q6", "Q15", "Q10"), collapse = '|')))


reactable(MR1_factor,
          defaultPageSize = 11)

reactable(MR2_factor)

reactable(MR3_factor)


head(conspiracy_data_10)


reactable(conspiracy_data_10)


conspiracy_data_10 %>%
  head() %>%
  rowSums()


head(EFA$scores)


summary(EFA$scores)


plot(density(EFA$scores, 
             na.rm = TRUE), 
     main = "Factor Scores")
