install.packages(
  c(
    "psych", "reactable", "polycor"
  ), dependencies = TRUE
)

remotes::install_github("peterhurford/surveytools2")
