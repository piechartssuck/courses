# Set the working directory where this R file is ----
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# Load multiple libraries using the pacman package ----
pacman::p_load("tidyverse", "tidytext", "janeaustenr", "tidyr", "scales", "wordcloud", "reshape2", "devtools", "gutenbergr")

# Change the default source for the gutenbergr package ----
alt_source <- "http://mirrors.xmission.com/gutenberg/"

# NOTE: 
# 1. Every time the text asks you to install a book using the
# gutenberg_download() command, you must add mirror = alt_source 
# to it - e.g. 
gutenberg_download(768, mirror = alt_source)

# 2. You can also see all of the texts available using the 
# gutenberg_works() command

#---# Copy and paste syntax from the text below #---#


