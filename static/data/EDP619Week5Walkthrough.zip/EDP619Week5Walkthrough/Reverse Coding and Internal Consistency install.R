install.packages(
  c(
    "remotes", "psych", "corrr"
  )
)

remotes::install_github("peterhurford/surveytools2")
