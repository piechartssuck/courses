install.packages("nasaweather")

library(nasaweather)

jan2001 <- subset(atmos, year == 2000 & month == 1)