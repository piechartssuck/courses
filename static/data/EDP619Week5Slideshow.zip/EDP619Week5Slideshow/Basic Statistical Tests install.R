install.packages(
  c(
    "car", "foreign", "lme4", "MASS", "CCA", "psych", "tidyverse"
  ),
  dependencies = TRUE
)

# Note: If you are asked to install from sources the package which needs compilation, please feel free to type in no.
