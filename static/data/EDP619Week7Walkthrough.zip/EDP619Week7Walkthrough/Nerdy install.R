install.packages(
  c(
    "mice", "naniar", "reactable"
  ), dependencies = TRUE
)
