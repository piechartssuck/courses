install.packages(
  c(
    "learnr", "RColorBrewer"
  )
)
