# 1. Run this
install.packages(
  c(
    "palmerpenguins", "Lock5Data", "tinytex"
  ),
  dependencies = TRUE
)

# 2. Then this
tinytex::install_tinytex()

