# Set the working directory where this R file is ----
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# Load multiple libraries using the pacman package ----
pacman::p_load("tidyverse", "tidymodels", "patchwork")

# Bring in the data set ----
happy_data <- 
  read_csv("World Happiness Report 2021.csv")


