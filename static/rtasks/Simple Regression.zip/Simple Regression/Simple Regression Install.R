install.packages(
  c(
    "pacman"
  ),
  dependencies = TRUE
)

pacman::p_load("tidyverse", "tidymodels", "patchwork")
