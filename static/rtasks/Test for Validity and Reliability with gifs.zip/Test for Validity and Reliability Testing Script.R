# Script that wrangles a Qualtrics numeric export. Please note that this is one of many approaches you can take to accomplish this

## Set the working directory where this R file is ----
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

## Load multiple libraries using the pacman package ----
pacman::p_load("tidyverse", "tidymodels", "patchwork", "corrr", "psych", "mice", "naniar", "reactable")

## Scratch work ----

### 1. Load Survey Data ----
### (only use this if you did not manually delete rows )
fake_data <- # variable name (change this as needed)
  read_csv("Test_Survey_Data.csv") %>% # data set name (change this as needed)
  slice(-(1:2)) %>% # Removes rows 2 and 3 (The discrepancy comes from the fact that R reads the first row as 0)
  select(starts_with("Q")) %>% # Selects only those columns that begin with the letter Q (change this as needed)
  mutate(across(c(1:13, 17), ~ as.numeric(.))) %>% # Convert columns 1-13 and 17 into numeric (change this as needed)
  select(where(is.numeric)) # Select only the numeric columns

### 2. Determine Missingness ----


### 3. Reliability ----


## 4. Validity ----


## 5. Reduce Dimensionality ----


