install.packages(
  c(
    "fivethirtyeight", "fontawesome", "scales", "wesanderson"
  )
)
