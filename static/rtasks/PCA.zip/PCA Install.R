install.packages(
  c(
    "broom", "GGally", "scales", "knitr", "kableExtra", "patchwork", "corrr"
  ),
  dependencies = TRUE
)


