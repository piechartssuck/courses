# Set the working directory where this R file is ----
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# Load multiple libraries using the pacman package ----
pacman::p_load("tidyverse", "broom", "patchwork", "corrr")

happy_landmass_data <- 
  read_csv("World Happiness Report 2021.csv") %>%
  select(-Country) %>%
  mutate(Contiguous = case_when(
    str_detect(Region, "America") ~ "Americas",
    str_detect(Region, "Asia") ~ "Asia"
  )
  ) %>%
  drop_na(Contiguous) %>%
  select(-Region)

# After first running the above, test your syntax under this comment

