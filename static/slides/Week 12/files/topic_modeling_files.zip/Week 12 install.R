# 1. Run this
install.packages(
  c(
    "tidyverse", "tidytext", "tm", "textclean", "topicmodels", "ldatuning", "stopwords", "textstem", "broom", "pdftools"
  ),
  dependencies = TRUE)