# Set current directory as source ----
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# Load packages ----
library(tidyverse)
library(tidytext)
library(tm)
library(textclean)
library(topicmodels)
library(ldatuning)
library(stopwords)
library(textstem)
library(broom)
library(lexicon)

# Load the data
employee_responses <- 
  read_csv("employee sample reviews.csv") 

# Load the common names set from the lexicon package ----
common_names <- 
  read_csv("most common names.csv") %>%
  simplify_all() %>%
  .[[1]]; common_names

# Clean the data
responses_cleaned <-
  employee_responses %>%
  select(feedback) %>%
  mutate(feedback = textclean::replace_non_ascii(feedback)) %>%
  mutate(feedback = str_to_lower(feedback)) %>%
  mutate(feedback = str_remove_all(feedback, "'s")) %>%
  mutate(feedback = str_remove_all(feedback, "[[:digit:]]")) %>%
  mutate(feedback = str_remove_all(feedback, "[[:punct:]]")) %>%
  mutate(feedback = str_remove_all(feedback, paste0("\\b", common_names, "\\b", collapse = "|"))) %>%
  mutate(feedback = str_remove_all(feedback, "mcknight|cook|cunningham|hahn|vargas")) %>%
  mutate(feedback = lemmatize_strings(feedback)) %>%
  mutate(feedback = str_squish(feedback)) %>%
  mutate(feedback = na_if(feedback, "")) %>%
  drop_na()

# Unnest tokens, get rid of stop words
responses_tokens <- 
  responses_cleaned %>%
  unnest_tokens(word, feedback) %>%
  anti_join(stop_words) %>%
  count(word, sort = TRUE) %>%
  add_column(document = 1)

# Convert to a document-term matrix
responses_dtm <- 
  responses_tokens %>%
  cast_dtm(document, word, n)

# Estimate number of topics
responses_topic_est <-
  FindTopicsNumber(
    responses_dtm,
    topics = seq(from = 2, to = 15, by = 1),
    metrics = c("Griffiths2004", "CaoJuan2009", "Arun2010", "Deveaud2014"),
    method = "Gibbs",
    control = list(seed = 77),
    mc.cores = 2L,
    verbose = TRUE
  )

FindTopicsNumber_plot(responses_topic_est)

# Find Topics
responses_lda <- 
  LDA(responses_dtm, 
      k = 6, 
      control = list(seed = 1234))

responses_topics <- 
  tidy(responses_lda, 
       matrix = "beta")

responses_topics

# Plot Topics
responses_top_terms <- 
  responses_topics %>%
  group_by(topic) %>%
  slice_max(beta, n = 10) %>% 
  ungroup() %>%
  arrange(topic, -beta)

responses_top_terms %>%
  mutate(term = reorder_within(term, beta, topic)) %>%
  ggplot(aes(beta, term, fill = factor(topic))) +
  geom_col(show.legend = FALSE) +
  scale_fill_viridis_d() +
  facet_wrap(~ topic, scales = "free") +
  scale_y_reordered() +
  theme_minimal()
