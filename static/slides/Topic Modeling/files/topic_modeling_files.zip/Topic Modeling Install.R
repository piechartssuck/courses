# 1. Run this
install.packages(
  c(
    "tidyverse", "tidytext", "tm", "textclean", "topicmodels", "ldatuning", "stopwords", "textstem", "broom", "remotes", "lexicon", "babynames"
  ),
  dependencies = TRUE)

# 2. Then this
remotes::install_github("lmullen/genderdata")
