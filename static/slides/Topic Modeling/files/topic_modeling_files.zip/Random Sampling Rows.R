# Set current directory as source ----
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# Load packages ----
library(tidyverse)


# 1. If you want a different random sample each time ----

## Sample the data set based on percentage ----
employee_sample <- 
  read_csv("employee reviews.csv", skip = 2) %>% # Skip the first two rows
  sample_frac(0.1) # Randomly sample 10% of the data (rows)

employee_sample

## Save sample as a csv ----
write_csv(employee_sample, "employee sample reviews.csv")



# 2. If you want the same sample consistently ----

## Run the following (seed and sample) each time
set.seed(123)
consistent_employee_sample <- 
  read_csv("employee reviews.csv", skip = 2) %>% # Skip the first two rows
  sample_frac(0.1) # Randomly sample 10% of the data (rows)

consistent_employee_sample

## Save sample as a csv ----
write_csv(consistent_employee_sample, "consistent employee sample reviews.csv")
