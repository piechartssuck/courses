# Set current directory as source ----
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# Load packages ----
library(tidyverse)
library(lexicon)
library(babynames)
library(genderdata)

# Get Common Names ----

## Most common names (smaller list) ----

## Via the census ----
lexicon_names <- 
  lexicon::common_names %>%
  as_tibble_col("name")

## Via babynames ----
babynames_names <- 
  babynames %>%
  select(name) %>%
  mutate(name = str_to_lower(name))

## Stack the two names sets and keep all unique instances ----
many_common_names <- 
  bind_rows(lexicon_names,
            babynames_names) %>%
  distinct()

# Save common names as a csv ----
write_csv(many_common_names, "many common names.csv")



## All common names (much larger list) ----

## Via the Social Security Administration by state ----
genderdata_state_names <- 
  genderdata::ssa_state %>%
  select(name); genderdata_state_names

## Via the Social Security Administration nationally ----
genderdata_national_names <-
  genderdata::ssa_national %>%
  select(name)

## Stack the four names sets and keep all unique instances ----
most_common_names <-
  bind_rows(lexicon_names,
            babynames_names,
            genderdata_state_names,
            genderdata_national_names) %>%
  distinct()

# Save common names as a csv ----
write_csv(most_common_names, "most common names.csv")
